/*
 * pe_homework.c  —  FileBuffer -> ImageBuffer -> NewBuffer
 *
 * 编译：直接放进 VS 工程，Ctrl+F5
 * 运行：读同目录的 test_target32.exe，生成 test_target32_new.exe
 *
 * 想把 .rdata 里的标记从 -A 改成 -B（M6 验证）：
 *   把下面的 PATCH_MARK 改成 1，重新生成，再运行。
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#ifndef PATCH_MARK
#define PATCH_MARK 1         /* 0 = 原样写回；1 = 把 -A 改成 -B 再写回 */
#endif

#define MAX_SEC 16

 /* ---------------- 数据结构 ---------------- */

typedef struct {
    char  name[9];
    DWORD va;         /* VirtualAddress   */
    DWORD vs;         /* VirtualSize      */
    DWORD rawPtr;     /* PointerToRawData */
    DWORD rawSize;    /* SizeOfRawData    */
} SEC;

typedef struct {
    PBYTE fileBuf;
    DWORD fileSize;
    DWORD e_lfanew;
    DWORD entry;
    DWORD secAlign;
    DWORD fileAlign;
    DWORD sizeOfImage;
    DWORD sizeOfHeaders;
    WORD  numSec;
    WORD  sizeOfOpt;
    DWORD secOff;
    SEC   sec[MAX_SEC];
} PE_INFO;

/* ---------------- 小工具 ---------------- */

static DWORD AlignUp(DWORD x, DWORD a) { return (x + a - 1) & ~(a - 1); }

static void wr32(BYTE* p, DWORD v)
{
    p[0] = (BYTE)(v & 0xFF);
    p[1] = (BYTE)((v >> 8) & 0xFF);
    p[2] = (BYTE)((v >> 16) & 0xFF);
    p[3] = (BYTE)((v >> 24) & 0xFF);
}

/* ---------------- 1. 读文件 ---------------- */

BOOL LoadFile(const char* path, PBYTE* outBuf, DWORD* outSize)
{
    FILE* fp;
    long  size;
    PBYTE buf;

    fp = fopen(path, "rb");
    if (!fp) { printf("[!] cannot open: %s\n", path); return FALSE; }

    fseek(fp, 0, SEEK_END);
    size = ftell(fp);
    if (size <= 0) { printf("[!] bad size: %ld\n", size); fclose(fp); return FALSE; }
    rewind(fp);

    buf = (PBYTE)malloc((size_t)size);
    if (!buf) { printf("[!] malloc failed\n"); fclose(fp); return FALSE; }

    if (fread(buf, 1, (size_t)size, fp) != (size_t)size) {
        printf("[!] short read\n");
        free(buf);
        fclose(fp);
        return FALSE;
    }
    fclose(fp);

    *outBuf = buf;
    *outSize = (DWORD)size;
    return TRUE;
}

BOOL SaveFile(const char* path, const PBYTE buf, DWORD size)
{
    FILE* fp = fopen(path, "wb");
    if (!fp) { printf("[!] cannot write: %s\n", path); return FALSE; }
    if (fwrite(buf, 1, size, fp) != size) {
        fclose(fp);
        printf("[!] short write\n");
        return FALSE;
    }
    fclose(fp);
    return TRUE;
}

/* ---------------- 2. 解析 PE ---------------- */

BOOL ParsePe(PBYTE buf, DWORD size, PE_INFO* pi)
{
    DWORD nt, opt;
    int   i;

    pi->fileBuf = buf;
    pi->fileSize = size;

    if (size < 0x40)                   return FALSE;
    if (*(WORD*)buf != 0x5A4D)         return FALSE;

    pi->e_lfanew = *(DWORD*)(buf + 0x3C);
    if (pi->e_lfanew + 0x18 > size)    return FALSE;

    nt = pi->e_lfanew;
    if (*(DWORD*)(buf + nt) != 0x4550) return FALSE;

    pi->numSec = *(WORD*)(buf + nt + 6);
    pi->sizeOfOpt = *(WORD*)(buf + nt + 20);
    if (pi->numSec == 0 || pi->numSec > MAX_SEC) return FALSE;

    opt = nt + 0x18;
    pi->entry = *(DWORD*)(buf + opt + 0x10);
    pi->secAlign = *(DWORD*)(buf + opt + 0x20);
    pi->fileAlign = *(DWORD*)(buf + opt + 0x24);
    pi->sizeOfImage = *(DWORD*)(buf + opt + 0x38);
    pi->sizeOfHeaders = *(DWORD*)(buf + opt + 0x3C);

    if (pi->fileAlign == 0 || pi->sizeOfImage == 0) return FALSE;

    pi->secOff = opt + pi->sizeOfOpt;
    for (i = 0; i < pi->numSec; i++) {
        BYTE* sh = buf + pi->secOff + i * 40;

        memcpy(pi->sec[i].name, sh, 8);
        pi->sec[i].name[8] = 0;
        pi->sec[i].vs = *(DWORD*)(sh + 0x08);
        pi->sec[i].va = *(DWORD*)(sh + 0x0C);
        pi->sec[i].rawSize = *(DWORD*)(sh + 0x10);
        pi->sec[i].rawPtr = *(DWORD*)(sh + 0x14);

        if (pi->sec[i].va + pi->sec[i].vs > pi->sizeOfImage) return FALSE;
        if (pi->sec[i].rawPtr + pi->sec[i].rawSize > size)   return FALSE;
    }
    return TRUE;
}

/* ---------------- 3. 拉伸：FileBuffer -> ImageBuffer ---------------- */

PBYTE FileToImage(const PE_INFO* pi)
{
    PBYTE img;
    DWORD i;

    /* 必须 calloc：BSS 区域靠它天然为 0 */
    img = (PBYTE)calloc(1, pi->sizeOfImage);
    if (!img) return NULL;

    memcpy(img, pi->fileBuf, pi->sizeOfHeaders);      /* 头 + 节表 */

    for (i = 0; i < pi->numSec; i++) {
        const SEC* s = &pi->sec[i];
        DWORD content = s->vs ? s->vs : s->rawSize;
        DWORD n = (content < s->rawSize) ? content : s->rawSize;
        if (n) memcpy(img + s->va, pi->fileBuf + s->rawPtr, n);
    }
    return img;
}

/* ---------------- 4. 压回：ImageBuffer -> NewBuffer ---------------- */

PBYTE ImageToFile(const PE_INFO* pi, const PBYTE img, DWORD* outSize)
{
    DWORD total, off, i, content, raw;
    PBYTE nb;

    /* 第一遍：只算总大小 */
    total = pi->sizeOfHeaders;
    for (i = 0; i < pi->numSec; i++) {
        content = pi->sec[i].vs ? pi->sec[i].vs : pi->sec[i].rawSize;
        total += AlignUp(content, pi->fileAlign);
    }

    nb = (PBYTE)calloc(1, total);
    if (!nb) return NULL;

    memcpy(nb, img, pi->sizeOfHeaders);               /* 先搬头 + 节表 */

    /* 第二遍：改 NewBuffer 里的节表副本，再拷数据 */
    off = pi->sizeOfHeaders;
    for (i = 0; i < pi->numSec; i++) {
        BYTE* sh = nb + pi->secOff + i * 40;

        content = pi->sec[i].vs ? pi->sec[i].vs : pi->sec[i].rawSize;
        raw = AlignUp(content, pi->fileAlign);

        wr32(sh + 0x10, raw);                 /* SizeOfRawData    */
        wr32(sh + 0x14, off);                 /* PointerToRawData */
        if (content) memcpy(nb + off, img + pi->sec[i].va, content);

        off += raw;
    }

    *outSize = total;
    return nb;
}

/* ---------------- 5. 可选：改字符串（M6） ---------------- */

static void PatchMark(PBYTE img, DWORD size)
{
    static const char from[] = "PE-LAB-MARK-32-A";
    static const char to[] = "PE-LAB-MARK-32-B";
    DWORD k;

    for (k = 0; k + sizeof(from) - 1 <= size; k++) {
        if (memcmp(img + k, from, sizeof(from) - 1) == 0) {
            memcpy(img + k, to, sizeof(to) - 1);
            printf("[patch] ImageBuffer + 0x%X : %s -> %s\n", k, from, to);
            return;
        }
    }
    printf("[patch] not found, skipped\n");
}

/* ---------------- 主程序 ---------------- */

int main(void)
{
    PBYTE   buf = NULL, img = NULL, nb = NULL;
    DWORD   size = 0, newSize = 0, i;
    PE_INFO pi;

    /* 1. 读文件 */
    if (!LoadFile("test_target32.exe", &buf, &size)) return 1;
    printf("fileSize = 0x%X (%lu)\n", size, (unsigned long)size);
    printf("first2   = 0x%04X\n", *(WORD*)buf);

    /* 2. 解析 */
    if (!ParsePe(buf, size, &pi)) {
        printf("[!] not a PE file\n");
        free(buf);
        return 1;
    }

    printf("e_lfanew      = 0x%X\n", pi.e_lfanew);
    printf("NumSec        = %u\n", pi.numSec);
    printf("SizeOfImage   = 0x%X\n", pi.sizeOfImage);
    printf("SizeOfHeaders = 0x%X\n", pi.sizeOfHeaders);
    printf("FileAlign     = 0x%X\n", pi.fileAlign);
    printf("SecTable      = 0x%X\n", pi.secOff);

    printf("\n  #  Name        VA          VS          RawPtr      RawSize\n");
    for (i = 0; i < pi.numSec; i++) {
        printf("  %d  %-8.8s  0x%08X  0x%08X  0x%08X  0x%08X\n",
            i, pi.sec[i].name,
            pi.sec[i].va, pi.sec[i].vs,
            pi.sec[i].rawPtr, pi.sec[i].rawSize);
    }

    /* 3. 拉伸 */
    printf("\n=== FileBuffer -> ImageBuffer ===\n");
    img = FileToImage(&pi);
    if (!img) { free(buf); return 1; }
    printf("ImageBuffer size : 0x%X (%lu)\n",
        pi.sizeOfImage, (unsigned long)pi.sizeOfImage);

    printf("[check] string at 0x15170 : %.16s\n", (const char*)(img + 0x15170));

#if PATCH_MARK
    PatchMark(img, pi.sizeOfImage);
#endif

    /* 4. 压回 */
    printf("\n=== ImageBuffer -> NewBuffer ===\n");
    nb = ImageToFile(&pi, img, &newSize);
    if (!nb) { free(img); free(buf); return 1; }
    printf("NewBuffer size : 0x%X (%lu)\n", newSize, (unsigned long)newSize);

    printf("\n  New section table:\n");
    for (i = 0; i < pi.numSec; i++) {
        BYTE* sh = nb + pi.secOff + i * 40;
        printf("    %-8.8s  RawPtr=0x%08X  RawSize=0x%08X\n",
            pi.sec[i].name,
            *(DWORD*)(sh + 0x14),
            *(DWORD*)(sh + 0x10));
    }

    /* 5. 写盘 */
    printf("\n=== Save ===\n");
    if (!SaveFile("test_target32_new.exe", nb, newSize)) {
        free(nb); free(img); free(buf);
        return 1;
    }
    printf("saved: test_target32_new.exe\n");

    free(nb);
    free(img);
    free(buf);
    return 0;
}