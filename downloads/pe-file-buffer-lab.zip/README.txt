﻿PE 文件缓冲区转换 —— 实验材料包
================================

一、包里有什么
---------------
main.c                  完整源码（FileBuffer → ImageBuffer → 新文件）
test_target32.exe       本次实验用的靶子文件（120,832 字节）
test_target32_new.exe   我这边跑出来的结果（139,264 字节），用来做对比
README.txt              本文件

注意：test_target32_new.exe 不是"标准答案"。它比原文件大了 18,432 字节（0x4800），
这正是文章最后一节专门讨论的现象，不是打包错了。


二、怎么编译运行（Visual Studio）
---------------------------------
1. VS 新建一个「空项目」（C 或 C++ 都行，语言标准不用改）
2. 把 main.c 加进项目：右键「源文件」→ 添加 → 现有项
3. 让程序能找到靶子文件，两种做法任选一种：
   a) 把 test_target32.exe 复制到编译输出目录（通常是 项目名\x64\Debug 或 项目名\Debug）
   b) 项目属性 → 调试 → 工作目录，改成 main.c 所在的那个文件夹
4. Ctrl+F5 运行（不调试启动）
5. 运行结束后，输出目录里会多出一个 test_target32_new.exe

没有 Visual Studio 也能编，但源码用了 <windows.h> 和 DWORD / PBYTE / BOOL 这些
Windows 类型，换到 Linux 或 gcc 下需要自己补类型定义，不建议新手折腾。


三、运行后大概会看到什么
-------------------------
fileSize = 0x1D800 (120832)
first2   = 0x5A4D
e_lfanew      = 0xF0
NumSec        = 5
SizeOfImage   = 0x1E000
SizeOfHeaders = 0x400
FileAlign     = 0x200
SecTable      = 0x1E8

  #  Name        VA          VS          RawPtr      RawSize
  0  .text       ...         ...         ...         ...
  ...（一共 5 个节：.text / .rdata / .data / .rsrc / .reloc）

=== FileBuffer -> ImageBuffer ===
ImageBuffer size : 0x1E000 (122880)
[check] string at 0x15170 : ...
[patch] ImageBuffer + 0x15xxx : PE-LAB-MARK-32-A -> PE-LAB-MARK-32-B

=== ImageBuffer -> NewBuffer ===
NewBuffer size : 0x22000 (139264)

=== Save ===
saved: test_target32_new.exe

具体数值以你实际运行为准，上面只是参考。


四、两个必须知道的点
---------------------
1) PATCH_MARK 开关（main.c 第 17-19 行）
       #define PATCH_MARK 1
   默认 1 = 把 .rdata 里的 "PE-LAB-MARK-32-A" 改成 "PE-LAB-MARK-32-B" 再写回。
   想原样写回（不做字符串替换），改成 0 重新编译即可。
   这个开关不影响文件大小，两种设置生成的新文件都是 139,264 字节。

2) 那一行写死偏移的检查语句（main.c 第 274 行附近）
       printf("[check] string at 0x15170 : %.16s\n", (const char*)(img + 0x15170));
   0x15170 是这个靶子文件里字符串的真实位置，专为它写的。
   换成别的 exe 就不会落在这里，会读到无效地址、甚至让程序直接崩掉。
   拿别的文件做实验时，把这行删掉，或者换成你自己算出来的偏移。


五、想复现文章最后一节的字节对比
---------------------------------
跑完之后用任意十六进制工具打开两个文件（ImHex、HxD、PE-bear 都行）：

  test_target32.exe      → 120,832 字节（0x1D800）
  test_target32_new.exe  → 139,264 字节（0x22000）

第一个不同的字节出现在偏移 0x249，正好落在节表里 .data 这一项的
SizeOfRawData 字段（原值 0x1A00 → 新值 0x6200）。

原因是 ImageToFile 里用 AlignUp(VirtualSize, FileAlignment) 重算了 SizeOfRawData：
.data 的 VirtualSize 是 0x6014，但文件里真正有数据的只有 0x1A00，
中间那 0x4614 是加载到内存时才补零的 BSS 区。
压回文件的时候把这整段补零区当成真实数据写了进去，文件就变大了。
新 exe 仍然能正常运行，因为多写进去的那段内容全是 0，不影响执行。


六、许可
---------
随便用、随便改，不用署名。靶子文件由 DeepSeek Harness 生成。
